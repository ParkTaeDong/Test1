% Optimization Toolbox Library
%
% Version 8.0 24-Jul-2017

%   Copyright 1990-2004 The MathWorks, Inc.
