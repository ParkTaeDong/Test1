function throwFminuncGradObjandLargeScaleWarning
% THROWFMINUNCGRADOBJANDLARGESCALEWARNING Throw 17a/b warning for fminunc
%
%   THROWFMINUNCGRADOBJANDLARGESCALEWARNING throws a warning for the
%   following case. For R2017a and R2017b only, we are still supporting
%   "optimset" users who specify the trust-region algorithm in fminunc via
%   the GradObj and LargeScale options for fminunc. From 18a onwards,
%   LargeScale will be ignored for fminunc and users will have to use
%   Algorithm.

%   @TODO: Remove this file in R2018a.

%   Copyright 2016 The MathWorks, Inc.

% Create CSH links
[linkTag1,endLinkTag1] = linkToAlgDefaultChangeCsh('fminunc_warn_alg_change'); % links to context sensitive help
[linkTag2,endLinkTag2] = linkToAlgDefaultChangeCsh('fminunc_warn_alg_change_optimset'); % links to context sensitive help
warning('optim:fminunc:WillRunDiffAlg', ...
    getString(message('optim:fminunc:WillRunDiffAlg',...
    linkTag1,endLinkTag1,linkTag2,endLinkTag2)));
