/*=================================================================
 * getuuid.cpp 
 * 
 * uses the boost library to return a unique ID.  Faster than typical java calls
 * found in matlab.bigdata.internal.util.UniqueIdFactory.
 *
 * ASSUMES: Single string input
 * RETURNS: Single unique ID mxStringArray
 *
 * This is a MEX-file for MATLAB.
 * Copyright 2017 The MathWorks, Inc.
 *=============================================================*/
#include "mex.h"
#include "fl/diag/terminate.hpp" 

#include <cstring>
#include <string>
#include <cstddef>

#include <boost/uuid/uuid.hpp>
#include <boost/uuid/random_generator.hpp>
#include <boost/uuid/uuid_io.hpp>

// turn off fancy compiler optimizations to maximize compatibility
#ifdef SIMD_ENABLE
#define BOOST_UUID_USE_SSE2
#else
#define BOOST_UUID_NO_SIMD
#endif

// Input vals
#define N_INPUTS    1
#define prependName prhs[0]

// Output vals
#define N_OUTPUTS   1
#define uniqueID    plhs[0]

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{   
	FL_DIAG_ASSERT(nrhs == N_INPUTS);
	FL_DIAG_ASSERT(mxIsChar(prependName));
	FL_DIAG_ASSERT(nlhs <= N_OUTPUTS);

	char *id_buf, *prepend_buf;
	std::size_t buflen_id, buflen_in;

	// get 
	buflen_in = mxGetN(prependName);
	prepend_buf = mxArrayToString(prependName);

    // create unique id and convert to string
	boost::uuids::random_generator gen;
	boost::uuids::uuid u = gen();

	std::string idStr = boost::uuids::to_string(u);

	// remove the dashes so name can be easily put into struct
	// field
	idStr[8] = idStr[13] = idStr[18] = idStr[23] = '0';
    
    // size + null char at end
	buflen_id = idStr.size() + buflen_in + 1;

    /* allocate memory for output string */
    id_buf=(char*) mxMalloc(buflen_id);
    
	std::memcpy(id_buf, prepend_buf, buflen_in);
    std::memcpy(id_buf+buflen_in, idStr.c_str(), idStr.size()+1);
    
    /* set C-style string output_buf to MATLAB mexFunction output*/
    uniqueID = mxCreateString(id_buf);
    
    return;
}

